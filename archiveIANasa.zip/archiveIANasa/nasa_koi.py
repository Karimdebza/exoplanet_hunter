import requests
import pandas as pd

# Archive NASA — tous les KOI avec statut CANDIDATE
url = "https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=select+kepid,koi_period,koi_disposition+from+cumulative+where+koi_disposition+like+'CANDIDATE'&format=csv"

response = requests.get(url)
with open('koi_candidates.csv', 'w') as f:
    f.write(response.text)

df = pd.read_csv('koi_candidates.csv')
print(f"KOI candidats : {len(df)}")
print(df.head(10))