import numpy as np
import tensorflow as tf
import lightkurve as lk
import matplotlib.pyplot as plt
from scipy.signal import savgol_filter
# 1. Charger le modèle (L'intelligence)
MODEL_PATH = 'exoplanet_cnn_v2.h5'
model = tf.keras.models.load_model(MODEL_PATH)

def predict_on_star(star_name, quarter=4):
    print(f"🔭 Analyse ciblée de {star_name}...")
    
    # 1. Téléchargement et nettoyage
    search = lk.search_lightcurve(star_name, author='Kepler', quarter=quarter)
    print(search)
    lc = search.download().remove_nans().flatten(window_length=101)
    
    # 2. Utiliser le BLS pour trouver le transit le plus fort
    # On cherche des périodes entre 1 et 20 jours
    bls = lc.to_periodogram(method='bls', period=np.linspace(1, 20, 5000))
    best_period = bls.period_at_max_power
    best_t0 = bls.transit_time_at_max_power
    
    print(f"📍 Transit suspecté trouvé à t0 = {best_t0.value:.2f} (Période: {best_period.value:.2f}j)")

    # 3. Extraire le segment pile sur le transit
    # On centre le segment de 200 points sur best_t0
    # On cherche l'index du point le plus proche de t0
    mid_idx = np.abs(lc.time.value - best_t0.value).argmin()
    
    start_idx = max(0, mid_idx - 100)
    end_idx = min(len(lc.flux), mid_idx + 100)
    
    segment = lc.flux.value[start_idx:end_idx]
    
    # Si le segment est trop court (bord de courbe), on ne prédit pas
    if len(segment) < 200:
        print("❌ Transit trop proche du bord de la courbe pour l'extraire.")
        return
    
    # 4. Normalisation et Lissage pour l'IA
    from scipy.signal import savgol_filter
    segment_clean = savgol_filter(segment - 1.0, window_length=11, polyorder=2)
    threshold = np.mean(segment_clean) - 2 * np.std(segment_clean)
    dip_width = np.sum(segment_clean < threshold)
    if dip_width > 40:
        print(f"⚠️  Dérive stellaire détectée ({dip_width} pts) — pas un transit")
        return
    
    left_noise = np.std(segment_clean[:50])
    right_noise = np.std(segment_clean[150:])
    ambient_noise = (left_noise + right_noise) / 2

    dip_depth = np.mean(segment_clean) - np.min(segment_clean)

    snr = dip_depth / (ambient_noise + 1e-8)
    print(f"SNR du creux: {snr:.2f}" )
    if snr < 3.0:
        print(f"⚠️  Creux noyé dans le bruit (SNR={snr:.2f}) — rejeté")
        return 

    X_input = segment_clean.reshape(-1, 200, 1)
    
    # 5. Prédiction
    prediction = model.predict(X_input, verbose=0)
    proba = prediction[0][0] * 100
    
    # 6. Affichage
    plt.figure(figsize=(10, 4))
    plt.plot(segment_clean)
    plt.axvline(x=100, color='r', linestyle='--', alpha=0.5, label='Centre du transit (BLS)')
    plt.title(f"{star_name} (Ciblé BLS) | Proba IA: {proba:.2f}%")
    plt.legend()
    plt.savefig(f"ciblé_{star_name}.png")
    print(f"✅ Analyse terminée. Image : ciblé_{star_name}.png")

def predict_on_star_multi(star_name, quarters=[3,4,5,6], period_range=(1,50)):
    print(f"🔭 Analyse multi-quarter de {star_name}...")
    
    # Télécharge et assemble plusieurs quarters
    lc = lk.search_lightcurve(star_name, author='Kepler', 
                               quarter=quarters).download_all().stitch()
    lc = lc.remove_nans().remove_outliers(sigma=5).flatten(window_length=401)
    
    # BLS sur toute la durée
    bls = lc.to_periodogram(method='bls', 
                             period=np.linspace(period_range[0], period_range[1], 10000))
    best_period = bls.period_at_max_power
    best_t0 = bls.transit_time_at_max_power
    
    print(f"📍 Période trouvée : {best_period.value:.2f}j | t0 = {best_t0.value:.2f}")
    
    # Cherche tous les transits à cette période
    flux = lc.flux.value
    time = lc.time.value
    
    transit_times = []
    t = best_t0.value
    while t < time[-1]:
        if t > time[0]:
            transit_times.append(t)
        t += best_period.value
    
    print(f"  Transits attendus : {len(transit_times)}")
    
    # Vérifie chaque transit
    validated = []
    for t_center in transit_times:
        mid_idx = np.abs(time - t_center).argmin()
        start = max(0, mid_idx - 100)
        end = min(len(flux), mid_idx + 100)
        
        if end - start < 200:
            continue
            
        segment = flux[start:end]
        from scipy.signal import savgol_filter
        seg_clean = savgol_filter(segment - 1.0, window_length=11, polyorder=2)
        
        # SNR
        left_noise = np.std(seg_clean[:50])
        right_noise = np.std(seg_clean[150:])
        snr = (np.mean(seg_clean) - np.min(seg_clean)) / ((left_noise+right_noise)/2 + 1e-8)
        
        if snr > 3.0:
            validated.append({'time': t_center, 'snr': snr})
    
    print(f"  Transits validés SNR>3 : {len(validated)}/{len(transit_times)}")
    
    if len(validated) >= 2:
        print(f"✅ CANDIDAT CONFIRMÉ — période {best_period.value:.2f}j")
    else:
        print(f"❌ Pas assez de transits validés")


def phase_fold_validate(star_name, period_nasa, quarters=[3,4,5,6]):
    print(f"🔭 Phase Folding {star_name} — période {period_nasa}j")
    
    lc = lk.search_lightcurve(star_name, author='Kepler',
                               quarter=quarters).download_all().stitch()
    lc = lc.remove_nans().remove_outliers(sigma=5).flatten(window_length=101)
    
    flux = lc.flux.value
    time = lc.time.value
    
    # Phase folding — ramène tout sur une période
    phase = ((time - time[0]) % period_nasa) / period_nasa
    phase[phase > 0.5] -= 1.0  # Centre sur 0
    
    # Trie par phase
    sort_idx = np.argsort(phase)
    phase_sorted = phase[sort_idx]
    flux_sorted  = flux[sort_idx]
    
    # Lisse le signal plié
    from scipy.signal import savgol_filter
    flux_smooth = savgol_filter(flux_sorted, window_length=51, polyorder=2)
    
    # SNR sur le signal plié
    center = np.abs(phase_sorted) < 0.05
    outside = np.abs(phase_sorted) > 0.2
    
    if center.sum() < 5 or outside.sum() < 10:
        print("❌ Pas assez de points pour calculer le SNR")
        return
        
    snr = (np.mean(flux_smooth[outside]) - np.min(flux_smooth[center])) / \
          (np.std(flux_smooth[outside]) + 1e-8)
    
    print(f"  SNR phase folded : {snr:.2f}")
    
    # Visualisation
    plt.figure(figsize=(10, 4))
    plt.scatter(phase_sorted, flux_sorted, s=1, alpha=0.3, color='steelblue')
    plt.plot(phase_sorted, flux_smooth, color='red', linewidth=2)
    plt.axvline(0, color='orange', linestyle='--', alpha=0.7)
    plt.title(f"{star_name} — Phase Fold {period_nasa}j | SNR={snr:.2f}")
    plt.xlabel("Phase")
    plt.ylabel("Flux normalisé")
    plt.xlim(-0.5, 0.5)
    plt.tight_layout()
    plt.savefig(f"fold_{star_name.replace(' ','_')}.png")
    print(f"✅ Image : fold_{star_name}.png")

def phase_fold_clean(star_name, period_nasa, quarters=[3,4,5,6]):
    print(f"🚀 Nettoyage haute précision pour {star_name}...")
    
    # 1. Téléchargement et Stitching propre
    search = lk.search_lightcurve(star_name, author='Kepler', quarter=quarters)
    lc = search.download_all().stitch()
    
    # 2. Detrending (on enlève les dérives sans tuer le transit)
    lc = lc.remove_nans().remove_outliers(sigma=5)
    lc = lc.flatten(window_length=401) # Lissage des variations stellaires
    
    # 3. Phase Folding avec recalage automatique
    # On cherche le t0 (le premier transit) pour centrer le graph
    temp_bls = lc.to_periodogram(method='bls', period=[period_nasa-0.01, period_nasa+0.01])
    best_t0 = temp_bls.transit_time_at_max_power
    
    folded_lc = lc.fold(period=period_nasa, epoch_time=best_t0)
    
    # 4. Le secret du "propre" : Le BINNING
    # On regroupe les points par petits paquets pour réduire le bruit
    binned_lc = folded_lc.bin(time_bin_size=0.01) # 0.01 phase = environ 15-30 min
    
    # 5. Plot
    import matplotlib.pyplot as plt
    plt.figure(figsize=(10, 6))
    
    # Points bruts en bleu clair
    plt.scatter(folded_lc.time.value, folded_lc.flux.value, s=1, color='dodgerblue', alpha=0.2, label="Points bruts")
    
    # Courbe lissée (Binned) en rouge
    plt.plot(binned_lc.time.value, binned_lc.flux.value, color='red', lw=3, label="Signal Moyen (Planète)")
    
    plt.title(f"Transit Haute Précision : {star_name}")
    plt.xlabel("Phase (Centrée sur le transit)")
    plt.ylabel("Luminosité relative")
    plt.legend()
    plt.grid(True, which='both', linestyle='--', alpha=0.5)
    
    # CRUCIAL : Sauvegarde le fichier pour pouvoir l'ouvrir !
    filename = f"PROPRE_{star_name}.png"
    plt.savefig(filename)
    print(f"📸 Image générée avec succès : {filename}")
    plt.close() # Libère la mémoire
    # Calcul du SNR amélioré sur la courbe binned
    snr = (1.0 - np.min(binned_lc.flux.value)) / np.std(binned_lc.flux.value)
    print(f"✅ SNR Final (Binned) : {snr:.2f}")

# TEST FINAL : On prend Kepler-5b pour la beauté du signal
# phase_fold_clean("Kepler-5", period_nasa=3.54)

# Lance sur nos deux candidats
# phase_fold_validate("KIC 11657614", period_nasa=24.35, quarters=[3,4,5,6])
# phase_fold_validate("KIC 4844367",  period_nasa=17.16, quarters=[3,4,5,6])
# phase_fold_validate("Kepler-10",  period_nasa=0.837, quarters=[3,4,5,6])


# Kepler-5b : Une géante gazeuse facile à voir
# phase_fold_validate("Kepler-5", period_nasa=3.54, quarters=[3,4,5,6])



# # Lance
# predict_on_star_multi("KIC 11657614", quarters=[3,4,5,6], period_range=(20,30))
# predict_on_star_multi("KIC 4844367",  quarters=[3,4,5,6], period_range=(5,10))


# Test direct sans passer par dataset.pkl
# predict_on_star("TrES-2", quarter=4)
# predict_on_star("Kepler-968", quarter=14)
# predict_on_star("KIC 7199397", quarter=4)
# predict_on_star("KIC 5955122", quarter=10)
# predict_on_star("KIC 4178389", quarter=4)   # période 23.2j — très précis
# predict_on_star("KIC 10602291", quarter=4)  # période 20.9j — très précis  
# predict_on_star("KIC 4844367", quarter=5)   # période 17.2j — 15 transits

# Le verdict honnête KIC 4844367 est probablement une étoile variable — elle produit des creux à des intervalles irréguliers qui ressemblent à des transits mais pas périodiques.
# for q in [7, 8, 9, 10, 11]:
#     try:
#         predict_on_star("KIC 4844367", quarter=q)
#     except:
#         print(f"Q{q} — pas de données")



# for q in [7, 8, 9, 10, 11, 12, 13, 14, 15]:
#     try:
#         print(f"--- Tentative Quarter {q} ---")
#         predict_on_star("KIC 11657614", quarter=q)
#     except Exception as e:
#         print(f"Q{q} échoué : {e}")