import pandas as pd
import lightkurve as lk
import numpy as np
import tensorflow as tf
import pickle

MODEL_PATH = 'exoplanet_cnn_v2.h5'
model = tf.keras.models.load_model(MODEL_PATH)

def merge_detections(detections, gap=300):
    if not detections:
        return []
    merged = []
    current = [detections[0]]
    for d in detections[1:]:
        if d['segment'] - current[-1]['segment'] <= gap:
            current.append(d)
        else:
            merged.append(max(current, key=lambda x: x['proba']))
            current = [d]
    merged.append(max(current, key=lambda x: x['proba']))
    return merged

def scan_koi(kepid, expected_period):
    star_name = f'KIC {kepid}'
    try:
        lc = lk.search_lightcurve(star_name, author='Kepler', quarter=[3,4,5]).download_all().stitch()
        lc = lc.remove_nans().remove_outliers(sigma=5).flatten(window_length=401)
        flux = lc.flux.value
        flux = (flux - np.mean(flux)) / (np.std(flux) + 1e-8)
        time = lc.time.value

        segments, times_mid = [], []
        for i in range(0, len(flux) - 200, 50):
            segments.append(flux[i:i+200])
            times_mid.append(time[i + 100])

        X = np.array(segments).reshape(-1, 200, 1)
        probas = model(X, training=False).numpy().flatten()

        detections = [
            {'segment': i*50, 'time': times_mid[i], 'proba': float(p)}
            for i, p in enumerate(probas) if p > 0.5
        ]
        merged = merge_detections(detections, gap=300)

        if len(merged) >= 3:
            intervals = [merged[i+1]['time'] - merged[i]['time']
                        for i in range(len(merged)-1)]
            period_detected = np.median(intervals)
            
            # Vérifie si la période détectée correspond à la période NASA
            period_match = abs(period_detected - expected_period) / expected_period < 0.2

            return {
                'kepid':          kepid,
                'star':           star_name,
                'n_transits':     len(merged),
                'period_nasa':    expected_period,
                'period_cnn':     period_detected,
                'period_match':   period_match,
                'max_proba':      max(d['proba'] for d in merged),
                'mean_proba':     float(np.mean(probas)),
            }
    except Exception as e:
        pass
    return None

if __name__ == "__main__":
    df = pd.read_csv('koi_candidates.csv')
    print(f"🔭 Scan de {len(df)} KOI candidats NASA...\n")
    
    results = []
    for i, row in df.iterrows():
        result = scan_koi(int(row['kepid']), float(row['koi_period']))
        if result:
            match = "✅ PÉRIODE CONFIRMÉE" if result['period_match'] else "⚠️  période différente"
            print(f"🪐 KIC {result['kepid']} | {result['n_transits']} transits "
                  f"| période NASA={result['period_nasa']:.2f}j "
                  f"| CNN={result['period_cnn']:.2f}j | {match}")
            results.append(result)
        
        if i % 50 == 0:
            print(f"  ... {i}/{len(df)} étoiles scannées")
            with open('koi_results_nasa.pkl', 'wb') as f:
                pickle.dump(results, f)
    
    confirmed = [r for r in results if r['period_match']]
    print(f"\n{'='*50}")
    print(f"✅ {len(confirmed)} candidats avec période confirmée par CNN")
    print(f"{'='*50}")
    for r in sorted(confirmed, key=lambda x: x['max_proba'], reverse=True)[:10]:
        print(f"  KIC {r['kepid']} | période {r['period_nasa']:.2f}j | proba {r['max_proba']:.3f}")
    
    with open('koi_results_nasa.pkl', 'wb') as f:
        pickle.dump(results, f)